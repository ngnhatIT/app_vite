export interface LoginRequestDTO{
    username:string,
    password:string
}