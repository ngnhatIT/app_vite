export interface RegisterRequestDTO{
    username:string;
    email:string;
    password:string;
}